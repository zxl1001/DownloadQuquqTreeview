/**
 *******************************************************************************
 *                       Continental Confidential
 *                  Copyright (c) Continental AG. 2017
 *
 *      This software is furnished under license and may be used or
 *      copied only in accordance with the terms of such license.
 *******************************************************************************
 * @file    MainWindow.cpp
 * @brief
 *******************************************************************************
 */
#include "MainWindow.h"
#include "ui_MainWindow.h"
#include <QCalendarWidget>
#include "ChildFrame.h"
#include "BDSDownloadQueueWidget.h"
#include <QDebug>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow),
    m_treeModel(new QStandardItemModel(this))
{
    ui->setupUi(this);
    m_treeModel->setColumnCount(1);
    m_treeModel->setHorizontalHeaderLabels(QStringList()<<"Name");
    ui->treeView->setIndentation(0);
    ui->treeView->setEditTriggers(QAbstractItemView::NoEditTriggers);
    ui->treeView->setSelectionBehavior(QAbstractItemView::SelectRows);
    ui->treeView->setModel(m_treeModel);
    for(int i=0; i<10; ++i)
    {
        QString title = QString("BDSR-0001_%1").arg(i);
        uint hash = qHash(title);
        appendItem(title,hash);
    }
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::appendItem(const QString &title, uint hash)
{

    QStandardItem *parnetItem = new QStandardItem("");
    m_treeModel->appendRow(parnetItem);
    const QModelIndex index =  m_treeModel->indexFromItem(parnetItem);
    BDSDownloadQueueWidget *item = new BDSDownloadQueueWidget(title,hash);
    ui->treeView->setIndexWidget(index, item);
    connect(item, SIGNAL(removItem(uint)), this, SLOT(removItem(uint)));
}

void MainWindow::removItem(uint hash)
{
    qDebug()<<"Delete item:"<<hash;
    for(int i = 0; i< m_treeModel->rowCount(); ++i)
    {
        const QModelIndex idx = m_treeModel->index(i,0);
        BDSDownloadQueueWidget *widget = static_cast<BDSDownloadQueueWidget *>(ui->treeView->indexWidget(idx));
        if(widget != Q_NULLPTR && widget->hashValue() == hash)
        {
            ui->treeView->setIndexWidget(idx, Q_NULLPTR);
            m_treeModel->removeRow(idx.row());
//            widget->disconnect();
            delete widget;
        }
    }
    m_treeModel->revert();
}


void MainWindow::on_appBtn_clicked()
{
    QString title = "zxl1001421321fasd3f";
    appendItem(title, qHash(title));
}
