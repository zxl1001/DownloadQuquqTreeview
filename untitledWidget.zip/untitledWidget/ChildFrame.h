/**
 *******************************************************************************
 *                       Continental Confidential
 *                  Copyright (c) Continental AG. 2017
 *
 *      This software is furnished under license and may be used or
 *      copied only in accordance with the terms of such license.
 *******************************************************************************
 * @file    ChildFrame.h
 * @brief
 *******************************************************************************
 */
#ifndef CHILDFRAME_H
#define CHILDFRAME_H

#include <QFrame>

namespace Ui {
class ChildFrame;
}

class ChildFrame : public QFrame
{
    Q_OBJECT

public:
    explicit ChildFrame(QWidget *parent = 0);
    ~ChildFrame();

private slots:
    void on_extenBtn_toggled(bool checked);

private:
    Ui::ChildFrame *ui;
};

#endif // CHILDFRAME_H
