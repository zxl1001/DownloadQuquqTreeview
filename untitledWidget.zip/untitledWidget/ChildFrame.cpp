/**
 *******************************************************************************
 *                       Continental Confidential
 *                  Copyright (c) Continental AG. 2017
 *
 *      This software is furnished under license and may be used or
 *      copied only in accordance with the terms of such license.
 *******************************************************************************
 * @file    ChildFrame.cpp
 * @brief
 *******************************************************************************
 */
#include "ChildFrame.h"
#include "ui_ChildFrame.h"

ChildFrame::ChildFrame(QWidget *parent) :
    QFrame(parent),
    ui(new Ui::ChildFrame)
{
    ui->setupUi(this);
}

ChildFrame::~ChildFrame()
{
    delete ui;
}

void ChildFrame::on_extenBtn_toggled(bool checked)
{
    if(!checked)
    {
        ui->calendarWidget->setVisible(true);
        resize(width(),300);
    }
    else
    {
        ui->calendarWidget->setVisible(false);
        resize(width(),30);
    }
}
